export const getTokenFromLocalStorage = () => {
    return localStorage.getItem('DTRMS_BY_M4RKBELLO');
  };