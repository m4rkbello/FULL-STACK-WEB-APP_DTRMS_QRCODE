export const getTokenFromSessionStorage = () => {
    return sessionStorage.getItem('DTRMS_BY_M4RKBELLO');
  };