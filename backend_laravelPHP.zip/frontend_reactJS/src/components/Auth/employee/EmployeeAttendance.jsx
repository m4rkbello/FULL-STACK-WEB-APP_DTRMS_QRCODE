import React from 'react';
import EmployeeChart from './EmployeeChart';

const EmployeeAttendance = () => {
  return (
    <div style={{ width: '100%', height: '100vh' }}>
      <EmployeeChart />
    </div>
  );
};

export default EmployeeAttendance;