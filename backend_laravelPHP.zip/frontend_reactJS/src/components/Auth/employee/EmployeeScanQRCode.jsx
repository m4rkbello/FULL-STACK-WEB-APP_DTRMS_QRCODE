import React from 'react'

const ScanQRCode = () => {
  return (
    <div>ScanQRCode</div>
  )
}

export default ScanQRCode